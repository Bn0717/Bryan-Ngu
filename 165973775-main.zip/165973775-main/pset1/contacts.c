#include <cs50.h>
#include <stdio.h>

int main(void)
{
    string first_name = get_string("What is your first name?");
    string last_name = get_string("What is your last name?");
    string age = get_string("What is your age?");
    string number = get_string("What is your phone number?");

    printf("%s%s%s%s\n", first_name, last_name, age, number);
}
